import 'package:flutter/material.dart';
import 'home.dart';
import 'book.dart';
import 'activity.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _currentIndex = 1;

  final List<Widget> _pages = const [
    BookPage(),
    
    HomeScreen(),
    
    ActivityPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [

          BottomNavigationBarItem(
            icon: Icon(Icons.local_parking),
            label: 'Book',
          ),
          
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),

          
          
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Activity',
          ),
        ],
      ),
    );
  }
}
