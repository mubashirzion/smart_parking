import 'package:flutter/material.dart';

class BookPage extends StatefulWidget {
  const BookPage({super.key});

  @override
  State<BookPage> createState() => _BookPageState();
}

class _BookPageState extends State<BookPage> {
  String action = 'BOOK';
  String selectedLocation = 'Downtown Parking';

  final List<Map<String, dynamic>> parkingLots = [
    {'name': 'Downtown Parking', 'distance': 0.5},
    {'name': 'City Center Parking', 'distance': 1.2},
    {'name': 'Mall Parking', 'distance': 2.0},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Parking Action')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            /// ACTION SELECTION
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        action = 'BOOK';
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          action == 'BOOK' ? Colors.blue : Colors.grey,
                    ),
                    child: const Text('Book Vehicle'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        action = 'RELEASE';
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          action == 'RELEASE' ? Colors.red : Colors.grey,
                    ),
                    child: const Text('Release Vehicle'),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            /// BOOK MODE
            if (action == 'BOOK') ...[
              DropdownButtonFormField<String>(
                value: selectedLocation,
                items: parkingLots
                    .map(
                      (lot) => DropdownMenuItem<String>(
                        value: lot['name'],
                        child: Text(
                          '${lot['name']} (${lot['distance']} km)',
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedLocation = value!;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Select Parking Location',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    _showMessage('Vehicle booked successfully');
                  },
                  child: const Text('Confirm Booking'),
                ),
              ),
            ],

            /// RELEASE MODE
            if (action == 'RELEASE') ...[
              const Card(
                child: ListTile(
                  leading: Icon(Icons.local_parking),
                  title: Text('Active Token #1023'),
                  subtitle: Text('Downtown Parking'),
                ),
              ),
              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    _showMessage('Vehicle released successfully');
                  },
                  child: const Text('Confirm Release'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }
}
