import 'package:flutter/material.dart';

class ActivityPage extends StatelessWidget {
  const ActivityPage({super.key});

  final List<Map<String, String>> activities = const [
    {
      'token': '#1023',
      'location': 'Downtown Parking',
      'status': 'BOOKED',
      'time': '10:30 AM'
    },
    {
      'token': '#1022',
      'location': 'City Center Parking',
      'status': 'RELEASED',
      'time': '09:10 AM'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activity Log')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: activities.length,
        itemBuilder: (context, index) {
          final item = activities[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.confirmation_number),
              title: Text(item['location']!),
              subtitle: Text(
                'Token ${item['token']} • ${item['time']}',
              ),
              trailing: Text(
                item['status']!,
                style: TextStyle(
                  color: item['status'] == 'BOOKED'
                      ? Colors.green
                      : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
