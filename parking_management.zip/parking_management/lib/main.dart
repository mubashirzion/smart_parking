import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'pages/login.dart';
import 'pages/dashboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://elexlbtrucairfrhtnlq.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVsZXhsYnRydWNhaXJmcmh0bmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY1MDE5NTMsImV4cCI6MjA4MjA3Nzk1M30.pcjAv0ckX9bmIZpoaB3RMPVH8yyfrBRDIN_76Rmuwsc',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Supabase.instance.client.auth.currentUser == null
          ? const LoginScreen()
          : const Dashboard(),
    );
  }
}